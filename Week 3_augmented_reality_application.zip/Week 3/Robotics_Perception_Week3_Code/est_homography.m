function [ H ] = est_homography(video_pts, logo_pts)
% est_homography estimates the homography to transform each of the
% video_pts into the logo_pts
% Inputs:
%     video_pts: a 4x2 matrix of corner points in the video
%     logo_pts: a 4x2 matrix of logo points that correspond to video_pts
% Outputs:
%     H: a 3x3 homography matrix such that logo_pts ~ H*video_pts
% Written for the University of Pennsylvania's Robotics:Perception course

% YOUR CODE HERE
H = [];
% Transformation which logo=T*(identity;1 1 1)
% Compute alpha,beta,gamma
matrix_logo=[logo_pts(1,:) 1;logo_pts(2,:) 1;logo_pts(3,:) 1]';
constants_logo=matrix_logo\[logo_pts(4,1);logo_pts(4,2);1];
T_matrix_logo=[constants_logo(1)*[logo_pts(1,:) 1]',constants_logo(2)*[logo_pts(2,:) 1]',constants_logo(3)*[logo_pts(3,:) 1]'];

% Transformation which video=T_diff*(identity;1 1 1)
% Compute alpha_@,beta_2,gamma_2
matrix_video=[video_pts(1,:) 1;video_pts(2,:) 1;video_pts(3,:) 1]';
constants_video=matrix_video\[video_pts(4,1);video_pts(4,2);1];
T_matrix_video=[constants_video(1)*[video_pts(1,:) 1]',constants_video(2)*[video_pts(2,:) 1]',constants_video(3)*[video_pts(3,:) 1]'];

H=T_matrix_logo/T_matrix_video;
end

