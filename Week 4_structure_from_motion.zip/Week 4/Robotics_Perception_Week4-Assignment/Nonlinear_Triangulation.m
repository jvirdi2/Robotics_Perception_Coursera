function X = Nonlinear_Triangulation(K, C1, R1, C2, R2, C3, R3, x1, x2, x3, X0)
%% Nonlinear_Triangulation
% Refining the poses of the cameras to get a better estimate of the points
% 3D position
% Inputs: 
%     K - size (3 x 3) camera calibration (intrinsics) matrix
%     x
% Outputs: 
%     X - size (N x 3) matrix of refined point 3D locations 
N1=size(X0);
store=X0;
for iter=1:10
    Xiter=store;
    for i=1:N1(1)
        X1=Single_Point_Nonlinear_Triangulation(K,C1,R1,C2,R2,C3,R3,x1(i,:),x2(i,:),x3(i,:),Xiter(i,:));
        store(i,:)=X1';
    end
end
X=store;
end

function X=Single_Point_Nonlinear_Triangulation(K,C1,R1,C2,R2,C3,R3,x1,x2,x3,X0)
    b=[x1 x2 x3]';
    N=size(X0);
    current_points_1=(K*R1*(X0'-C1.*ones(3,N(1))))';
    current_points_2=(K*R2*(X0'-C2.*ones(3,N(1))))';
    current_points_3=(K*R3*(X0'-C3.*ones(3,N(1))))';
    u_1=current_points_1(:,1);
    v_1=current_points_1(:,2);
    w_1=current_points_1(:,3);
    u_2=current_points_2(:,1);
    v_2=current_points_2(:,2);
    w_2=current_points_2(:,3);
    u_3=current_points_3(:,1);
    v_3=current_points_3(:,2);
    w_3=current_points_3(:,3);
    fx=[u_1./w_1 v_1./w_1 u_2./w_2 v_2./w_2 u_3./w_3 v_3./w_3]';
    J1=Jacobian_Triangulation(C1, R1, K, X0);
    J2=Jacobian_Triangulation(C2, R2, K, X0);
    J3=Jacobian_Triangulation(C3, R3, K, X0);
    J=[J1 J2 J3]';
    delX=((J'*J)\J')*(b-fx);
    X=X0'+delX;
end

function J = Jacobian_Triangulation(C, R, K, X)
f=K(1,1);
px=K(1,3);
py=K(2,3);
dui_dX=[f*R(1,1)+px*R(3,1) f*R(1,2)+px*R(3,2) f*R(1,3)+px*R(3,3)]; 
dvi_dX=[f*R(2,1)+py*R(3,1) f*R(2,2)+py*R(3,2) f*R(2,3)+py*R(3,3)]; 
dwi_dX=R(3,:);
N2=size(X);
current_points=(K*R*(X'-C.*ones(3,N2(1))))';
ui=current_points(:,1);
vi=current_points(:,2);
wi=current_points(:,3);
dfi_dx=[(wi.*dui_dX-ui.*dwi_dX)./(wi.^2);(wi.*dvi_dX-vi.*dwi_dX)./(wi.^2)];
J=dfi_dx';
end
