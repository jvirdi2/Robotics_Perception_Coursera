function E = EssentialMatrixFromFundamentalMatrix(F,K)
%% EssentialMatrixFromFundamentalMatrix
% Use the camera calibration matrix to esimate the Essential matrix
% Inputs:
%     K - size (3 x 3) camera calibration (intrinsics) matrix
%     F - size (3 x 3) fundamental matrix from EstimateFundamentalMatrix
% Outputs:
%     E - size (3 x 3) Essential matrix with singular values (1,1,0)

E_temp=K'*F*K;
[U_E,D_E,V_E]=svd(E_temp);
E_temp_2=U_E*[1 0 0;0 1 0;0 0 0]*V_E';
E=E_temp_2/norm(E_temp_2)
end

