function [C, R] = LinearPnP(X, x, K)
%% LinearPnP
% Getting pose from 2D-3D correspondences
% Inputs:
%     X - size (N x 3) matrix of 3D points
%     x - size (N x 2) matrix of 2D points whose rows correspond with X
%     K - size (3 x 3) camera calibration (intrinsics) matrix
% Outputs:
%     C - size (3 x 1) pose transation
%     R - size (3 x 1) pose rotation
%
% IMPORTANT NOTE: While theoretically you can use the x directly when solving
% for the P = [R t] matrix then use the K matrix to correct the error, this is
% more numeically unstable, and thus it is better to calibrate the x values
% before the computation of P then extract R and t directly


x_length=size(x);
N=x_length(1);%Get N
x_homo=[x,ones(N,1)];
xc_homo=K\x_homo'; % calibrated x values
xc_1=xc_homo';
xc_final=xc_1./(xc_1(:,3));
big_matrix=zeros(3*N,12);
for i=1:N
    first_pdt_row=[0 0 0,-(X(i,:)),xc_final(i,2)*(X(i,:)),0 -1 xc_final(i,2)];
    second_pdt_row=[(X(i,:)),0 0 0,-xc_final(i,1)*(X(i,:)),1 0 -xc_final(i,1)];
    third_pdt_row=[-1*xc_final(i,2)*(X(i,:)),xc_final(i,1)*(X(i,:)),0 0 0,-xc_final(i,2) xc_final(i,1) 0];
    combined_big_row=[first_pdt_row;second_pdt_row;third_pdt_row];
    big_matrix(3*i-2:3*i,:)=combined_big_row;
end

[U,D,V]=svd(big_matrix);
size_V=size(V);
last_V_vector=V(:,size_V(2))/V(size_V(1),size_V(2)); % This has elements of temporary P
P=[[last_V_vector(1:3)',last_V_vector(10)];[last_V_vector(4:6)',last_V_vector(11)];[last_V_vector(7:9)',last_V_vector(12)]];
rotation_translation_combined=P;%K\P,since already K has been used up in calibrating x, so not used again;
R_before=rotation_translation_combined(:,1:3);
t_before=rotation_translation_combined(:,4);
[U_R,D_R,V_R]=svd(R_before);
det(U_R*V_R')
if det(U_R*V_R')>0
  R=U_R*V_R';
  tc=t_before/D_R(1,1);
  C=-R'*tc;
else
  R=(-1)*U_R*V_R';
  tc=(-1)*t_before/D_R(1,1);
  C=(-1)*R'*tc;
end
end

