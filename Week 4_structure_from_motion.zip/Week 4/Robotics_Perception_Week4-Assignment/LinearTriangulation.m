function X = LinearTriangulation(K, C1, R1, C2, R2, x1, x2)
%% LinearTriangulation
% Find 3D positions of the point correspondences using the relative
% position of one camera from another
% Inputs:
%     C1 - size (3 x 1) translation of the first camera pose
%     R1 - size (3 x 3) rotation of the first camera pose
%     C2 - size (3 x 1) translation of the second camera
%     R2 - size (3 x 3) rotation of the second camera pose
%     x1 - size (N x 2) matrix of points in image 1
%     x2 - size (N x 2) matrix of points in image 2, each row corresponding
%       to x1
% Outputs: 
%     X - size (N x 3) matrix whos rows represent the 3D triangulated
%       points

P1=K*[R1,-R1*C1];
P2=K*[R2,-R2*C2];
x1_length=size(x1);
N=x1_length(1);%Get N
x1_homo=[x1,ones(N,1)];
x2_homo=[x2,ones(N,1)]; %Since they are corresponding points, so equal number of 1

Xtemp_2=zeros(N,4);
for i=1:N
    skew1=Vec2Skew(x1_homo(i,:));
    skew2=Vec2Skew(x2_homo(i,:));
    six_cross_4_matrix=[skew1*P1;skew2*P2];
    [u,d,v]=svd(six_cross_4_matrix);
    Xtemp=v(:,end)/v(end,end);
    Xtemp_2(i,:)=Xtemp';
end

X=Xtemp_2(:,1:3);
end
