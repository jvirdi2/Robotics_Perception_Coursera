function F = EstimateFundamentalMatrix(x1, x2)
%% EstimateFundamentalMatrix
% Estimate the fundamental matrix from two image point correspondences 
% Inputs:
%     x1 - size (N x 2) matrix of points in image 1
%     x2 - size (N x 2) matrix of points in image 2, each row corresponding
%       to x1
% Output:
%    F - size (3 x 3) fundamental matrix with rank 2
x1_length=size(x1);
N=x1_length(1);%Get N
x1_homo=[x1,ones(N,1)];
x2_homo=[x2,ones(N,1)]; %Since they are corresponding points, so equal number of 1
big_matrix=zeros(N,9);
for i=1:N
    first_pdt_row=x1_homo(i,1)*x2_homo(i,:);
    second_pdt_row=x1_homo(i,2)*x2_homo(i,:);
    third_pdt_row=x1_homo(i,3)*x2_homo(i,:);
    combined_big_row=[first_pdt_row,second_pdt_row,third_pdt_row];
    big_matrix(i,:)=combined_big_row;
end

[U,D,V]=svd(big_matrix);
size_V=size(V);
last_V_vector=V(:,size_V(2)); % This has elements of temporary F
F_temp=reshape(last_V_vector,3,3);
[U_F,D_F,V_F]=svd(F_temp);
D_F(3,3)=0;
F_cleanup=U_F*D_F*V_F';
F=F_cleanup/norm(F_cleanup);
end



        
